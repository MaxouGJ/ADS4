public enum Sym {
    STR,
    INT,
    PLUS,
    MOINS,
    MULT,
    LPAR,
    RPAR,
    EOF;  //token representinting the end of file
}

public enum Sym {
    STR,
    PLUS,
    MOINS,
    LPAR,
    RPAR,
    EOF;  //token representinting the end of file
}

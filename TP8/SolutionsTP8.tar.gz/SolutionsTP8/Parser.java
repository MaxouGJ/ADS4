import java.io.*;
import java.util.*;

class Parser {
	/*
	 * Code -> Prog$
     * Prog -> e | Inst Prog
     * Inst -> VAR var; | var = Exp; | PRINT Exp; | FOR Exp TIMESDO {Prog}
	 * Exp -> int | (Exp ExpSuite)
     * ExpSuite -> + Exp | - Exp | * Exp | / Exp
	 */
    protected LookAhead1 reader;

    public Parser(LookAhead1 r) {
	   reader=r;
    }

    public Program nontermCode() 
    throws Exception {
        Program prog = nontermProg();
        reader.eat(Sym.EOF);
        return prog;
    }

    public Program nontermProg()
    throws Exception {
        if (reader.check(Sym.VAR) || reader.check(Sym.VARIABLE) ||
            reader.check(Sym.PRINT) || reader.check(Sym.FOR)) {
            Instruction i = nontermInst();
            Program p = nontermProg();
            return new Program(i, p);
        } else {
            return new Program(null, null);
        }
    }

    public Instruction nontermInst()
    throws Exception {
        if (reader.check(Sym.VAR)) {
            reader.eat(Sym.VAR);
            String varName = reader.getStringValue();
            reader.eat(Sym.VARIABLE);
            reader.eat(Sym.CONCAT);
            return new Declaration(varName);
        }
        if (reader.check(Sym.VARIABLE)) {
            String varName = reader.getStringValue();
            reader.eat(Sym.VARIABLE);
            reader.eat(Sym.EQ);
            Expression exp = nontermExp();
            reader.eat(Sym.CONCAT);
            return new Assignment(varName, exp);
        }
        if (reader.check(Sym.PRINT)) {
            reader.eat(Sym.PRINT);
            Expression exp = nontermExp();
            reader.eat(Sym.CONCAT);
            return new Print(exp);
        }
        if (reader.check(Sym.FOR)) {
            reader.eat(Sym.FOR);
            Expression exp = nontermExp();
            reader.eat(Sym.TIMESDO);
            reader.eat(Sym.LACC);
            Program prog = nontermProg();
            reader.eat(Sym.RACC);
            return new Loop(exp, prog);
        }   
        throw new ParserException(reader.getString());
    }

    public Expression nontermExp() 
    throws Exception {
        if (reader.check(Sym.LPAR)) {
            reader.eat(Sym.LPAR);
            Expression exp = nontermExp();
            exp = nontermExpSuite(exp);
            reader.eat(Sym.RPAR);
            return exp;
        }
        if (reader.check(Sym.INT)) {
            int n = reader.getIntValue();
            reader.eat(Sym.INT);
            return new Int(n);
        }
        if (reader.check(Sym.VARIABLE)) {
            String s = reader.getStringValue();
            reader.eat(Sym.VARIABLE);
            return new Var(s);
        }
        throw new ParserException(reader.getString());
    }

    public Expression nontermExpSuite(Expression beginning) 
    throws Exception {
        if (reader.check(Sym.PLUS)) {
            reader.eat(Sym.PLUS);
            Expression end = nontermExp();
            return new Sum(beginning, end);
        }
        if (reader.check(Sym.MINUS)) {
            reader.eat(Sym.MINUS);
            Expression end = nontermExp();
            return new Difference(beginning, end);
        }
        if (reader.check(Sym.TIMES)) {
            reader.eat(Sym.TIMES);
            Expression end = nontermExp();
            return new Product(beginning, end);
        }
        if (reader.check(Sym.DIV)) {
            reader.eat(Sym.DIV);
            Expression end = nontermExp();
            return new Division(beginning, end);
        }
        throw new ParserException(reader.getString());
    }
}

import java.util.*;

abstract class Expression {
    abstract int eval(ValueEnvironment env)
    throws Exception;
    abstract String toJava();
}
class Int extends Expression {
	private int value;
	public Int(int i) {
		value = i;
	}
	public int eval(ValueEnvironment env)
	throws Exception {
		return value;
	}
	public String toJava() {
		return "" + value;
	}
}
class Var extends Expression {
	private String name;
	public Var(String s) {
		name = s;
	}
	public int eval(ValueEnvironment env)
	throws Exception {
		return env.getValue(name);
	}
	public String toJava() {
		return "_" + name;
	}
}
class Sum extends Expression {
	private Expression left, right;
	public Sum(Expression l, Expression r) {
		left = l;
		right = r;
	}
	public int eval(ValueEnvironment env)
	throws Exception {
		return left.eval(env) + right.eval(env);
	}
	public String toJava() {
		return "(" + left.toJava() + " + " + right.toJava() + ")";
	}
}
class Difference extends Expression {
	private Expression left, right;
	public Difference(Expression l, Expression r) {
		left = l;
		right = r;
	}
	public int eval(ValueEnvironment env)
	throws Exception {
		return left.eval(env) - right.eval(env);
	}
	public String toJava() {
		return "(" + left.toJava() + " - " + right.toJava() + ")";
	}
}
class Product extends Expression {
	private Expression left, right;
	public Product(Expression l, Expression r) {
		left = l;
		right = r;
	}
	public int eval(ValueEnvironment env)
	throws Exception {
		return left.eval(env) * right.eval(env);
	}
	public String toJava() {
		return "(" + left.toJava() + " * " + right.toJava() + ")";
	}
}
class Division extends Expression {
	private Expression left, right;
	public Division(Expression l, Expression r) {
		left = l;
		right = r;
	}
	public int eval(ValueEnvironment env)
	throws Exception {
		return left.eval(env) / right.eval(env);
	}
	public String toJava() {
		return "(" + left.toJava() + " / " + right.toJava() + ")";
	}
}

class Program {
	private Instruction first;
	private Program rest;
	public Program(Instruction i, Program p) {
		first = i;
		rest = p;
	}
	public void run(ValueEnvironment env) 
	throws Exception {
		if (first != null) {
			first.exec(env);
			rest.run(env);
		}
	}
	public String toJava(int indent) {
		String res;
		if (first == null) return "";
		if (indent <= 0) 
			return "public class TransProgram {\n" + 
				   "\tpublic static void main(String[] args) {\n" +
				   this.toJava(2) + 
				   "\t} \n} \n";
		return first.toJava(indent) + rest.toJava(indent);
	}
}

abstract class Instruction {
	abstract void exec(ValueEnvironment env)
	throws Exception;
	abstract String toJava(int indent);
}
class Declaration extends Instruction {
	private String varName;
	public Declaration(String s) {
		varName = s;
	}
	public void exec(ValueEnvironment env) 
	throws Exception {
		env.addVariable(varName);
	}
	public String toJava(int indent) {
		String tabs = "";
		for (int i = 0; i < indent; i++)
			tabs = tabs + "\t";
		return tabs + "int _" + varName + ";\n";
	} 
}
class Assignment extends Instruction {
	private String varName;
	private Expression exp;
	public Assignment(String s, Expression e) {
		varName = s;
		exp = e;
	}
	public void exec(ValueEnvironment env)
	throws Exception {
		env.setVariable(varName, exp.eval(env));
	}
	public String toJava(int indent) {
		String tabs = "";
		for (int i = 0; i < indent; i++)
			tabs = tabs + "\t";
		return tabs + "_" + varName + " = " + exp.toJava() + ";\n";
	} 
}
class Print extends Instruction {
	private Expression exp;
	public Print(Expression e) {
		exp = e;
	}
	public void exec(ValueEnvironment env) 
	throws Exception {
		System.out.println(exp.eval(env));
	}
	public String toJava(int indent) {
		String tabs = "";
		for (int i = 0; i < indent; i++)
			tabs = tabs + "\t";
		return tabs + "System.out.println(" + exp.toJava() + ");\n";
	} 
}
class Loop extends Instruction {
	private Expression exp;
	private Program prog;
	private static int loops = 0;
	public Loop(Expression e, Program p) {
		exp = e;
		prog = p;
	}
	public void exec(ValueEnvironment env)
	throws Exception {
		int n = exp.eval(env);
		for (int i = 0; i < n; i++) {
			prog.run(env);
		}
	}
	public String toJava(int indent) {
		String tabs = "";
		for (int i = 0; i < indent; i++)
			tabs = tabs + "\t";
		return tabs + "int __n" + loops + " = " + exp.toJava() + ";\n" +
			   tabs + "for (int __i" + indent + " = 0; " +
			   "__i" + indent + " < __n" + loops++ + "; " +
			   "__i" + indent + "++) {\n" +
			   prog.toJava(indent + 1) +
			   tabs + "} \n";
	} 
}

class ValueEnvironment extends HashMap<String, Integer> {
	public ValueEnvironment() {
		super();
	}
	public void addVariable(String name) 
	throws Exception {
		if (this.containsKey(name)) 
			throw new VariableTwiceDefinedException(name);
		this.put(name, null);
	}
	public void setVariable(String name, int value) 
	throws Exception {
		if (!this.containsKey(name))
			throw new VariableNotDefinedException(name);
		this.put(name, value);
	}
	public int getValue(String name) 
	throws Exception {
		if (!this.containsKey(name))
			throw new VariableNotDefinedException(name);
		Integer value = this.get(name);
		if (value == null)
			throw new VariableNotInitializedException(name);
		return value;
	}
}

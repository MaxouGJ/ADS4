public class TransProgram {
  public static void main(String[] args) {
    int _x;
    int _y;
    int _z;
    System.out.println(1);
    _x = 2;
    _z = 0;
    int __n0 = (10 + _x);
    for (int __i2 = 0; __i2 < __n0; __i2++) {
      _y = 10;
      _z = (_z + _y);
    } 
    System.out.println(_z);
  } 
} 


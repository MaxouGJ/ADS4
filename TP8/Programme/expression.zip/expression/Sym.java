public enum Sym {
    LPAR,
    RPAR,
    INT,
    PLUS,
    MINUS,
    TIMES,
    DIV,
    EOF;  //token representinting the end of file
}

import java.io.*;
import java.util.*;

class Parser {
	/*
	 * S -> Exp$
	 * Exp -> int | (Exp ExpSuite)
     * ExpSuite -> + Exp | - Exp | * Exp | / Exp
	 */
    protected LookAhead1 reader;

    public Parser(LookAhead1 r) {
	   reader=r;
    }
    public Expression nontermS() 
    throws Exception {
        Expression exp = nontermExp();
        reader.eat(Sym.EOF);
        return exp;
    }
    //Complétez ici...